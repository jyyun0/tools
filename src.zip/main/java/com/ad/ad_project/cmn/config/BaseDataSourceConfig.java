/**
 * 
 */
package com.ad.ad_project.cmn.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;

import com.zaxxer.hikari.HikariConfig;

import lombok.extern.slf4j.Slf4j;

/**
 * @author user
 *
 */
@Slf4j
@Configuration
@PropertySource("classpath:/application.properties")
@MapperScan(value = "com.ad.mapper", sqlSessionFactoryRef = "baseSqlSessionFactory")
public class BaseDataSourceConfig {
	@Autowired
	private ApplicationContext applicationContext;

	//@Value("${spring.base.datasource.mapper-locations}")
	//private String mapperLocations;

	//@Value("${spring.base.datasource.mybatis-config}")
	//private String configPath;

//		@Bean(name = "baseHikariConfig")
//		@Primary
//		@ConfigurationProperties(prefix = "spring.base.datasource")
//		public HikariConfig baseHikariConfig() {
//			return new HikariConfig();
//		}


	@Bean(name="baseDataSource")
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource.hikari.base.")
	public DataSource baseDataSource() {
		DataSource dataSource = DataSourceBuilder.create(HikariConfig.class).build();
		log.info("Datasource : {}", dataSource);
		return dataSource;
	}

	@Bean(name = "baseSqlSessionFactory")
	@Primary
	public SqlSessionFactory baseSqlSessionFactory(@Qualifier("baseDataSource") DataSource dataSource) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSource);
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:/mapper/base/**/*Mapper.xml"));
		sqlSessionFactoryBean.getObject().getConfiguration().setMapUnderscoreToCamelCase(true);

		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "baseSqlSessionTemplate")
	@Primary
	public SqlSessionTemplate baseSqlSessionTemplate(
			@Qualifier("baseSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory);
	}
}