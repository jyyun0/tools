/**
 * 
 */
package com.ad.ad_project.cmn.module.crypto;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @author user
 *
 */
public class HashUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		System.out.println(HashUtil.md5("abcdefghijklmn"));
		System.out.println(HashUtil.sha256("abcdefghijklmn"));
	}

	public static String md5(String msg) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(msg.getBytes());
		return HashUtil.byteToHexString(md.digest());
	}
	
	public static String sha256(String msg)  throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.update(msg.getBytes());
		return HashUtil.byteToHexString(md.digest());
	}

	public static String byteToHexString(byte[] data) {
	    StringBuilder sb = new StringBuilder();
	    for(byte b : data) {
	        sb.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
	    }
	    return sb.toString();
	}

}
