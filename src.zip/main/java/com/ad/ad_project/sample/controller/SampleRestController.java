package com.ad.ad_project.sample.controller;

import javax.annotation.Resource;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ad.ad_project.cmn.entity.session.SessionEntity;
import com.ad.ad_project.sample.vo.SampleVo;

@RestController
public class SampleRestController {
	
	@Resource
	private SessionEntity sessionEntity;

	@RequestMapping(value="/get_request_body",
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
	public SampleVo getRequestBody(@RequestBody SampleVo vo) {
		return vo;
	}
	
	@RequestMapping(value="/get_session_data",
			method = RequestMethod.GET)
	public SampleVo getSessionData() {
		
		SampleVo vo = new SampleVo();
		vo.setId(sessionEntity.getUserId());
		vo.setName(sessionEntity.getUserName());
		
		sessionEntity.setUserId("aaa");
		sessionEntity.setUserName("bbb");
		
		return vo;
	}

}
