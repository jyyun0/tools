/**
 * 
 */
package com.ad.ad_project.sample.vo;

import lombok.Data;

/**
 * @author user
 *
 */
@Data
public class SampleVo {
	
	private String id;
	private String name;
	private String address;
}
