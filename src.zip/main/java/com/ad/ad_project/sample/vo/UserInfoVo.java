package com.ad.ad_project.sample.vo;

import lombok.Data;

@Data
public class UserInfoVo {
	private String name;
	private String age;
}
