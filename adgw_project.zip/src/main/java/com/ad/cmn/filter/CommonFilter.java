/**
 * 
 */
package com.ad.cmn.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * @author user
 *
 */
@Slf4j
@Component
public class CommonFilter extends AbstractGatewayFilterFactory<CommonFilter.Config> {

	public CommonFilter() {
		super(Config.class);
	}
	
	public GatewayFilter apply(Config config) {
		
		return ((exchange, chain) -> {
			log.info("Common Filter : " + config.getBaseMessage());
			
			ServerHttpRequest request = exchange.getRequest().mutate().build();
			return chain.filter(exchange.mutate().request(request).build());
		});
	}
	
	@Data
	public static class Config {
		private String baseMessage;
	}
}
