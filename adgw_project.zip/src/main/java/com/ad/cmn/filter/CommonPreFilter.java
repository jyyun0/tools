/**
 * 
 */
package com.ad.cmn.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * @author user
 *
 */
@Slf4j
@Component
public class CommonPreFilter extends AbstractGatewayFilterFactory<CommonPreFilter.Config> {

	public CommonPreFilter() {
		super(Config.class);
	}
	
	public GatewayFilter apply(Config config) {
		
		return ((exchange, chain) -> {
			log.info("Common Prefilter Filter : " + config.getBaseMessage());
			
			ServerHttpRequest request = exchange.getRequest().mutate().header("AD_PRE_HEADER", "ADGW").build();
			return chain.filter(exchange.mutate().request(request).build());
		});
	}
	
	@Data
	public static class Config {
		private String baseMessage;
	}
}
