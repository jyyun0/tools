/**
 * 
 */
package com.ad.cmn.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

/**
 * @author user
 *
 */
@Slf4j
@Component
public class CommonPostFilter extends AbstractGatewayFilterFactory<CommonPostFilter.Config> {

	public CommonPostFilter() {
		super(Config.class);
	}
	
	public GatewayFilter apply(Config config) {
		
		return ((exchange, chain) -> {
			log.info("Common Postfilter Filter : " + config.getBaseMessage());
			
			return chain.filter(exchange).then(Mono.fromRunnable(() -> {
				ServerHttpResponse response = exchange.getResponse();
				HttpHeaders headers = response.getHeaders();
				headers.forEach((k,v) -> {
					log.debug(k + ":" + v);
				});
			}));
		});
	}
	
	@Data
	public static class Config {
		private String baseMessage;
	}
}
