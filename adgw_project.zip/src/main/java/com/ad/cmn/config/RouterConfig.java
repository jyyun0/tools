package com.ad.cmn.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ad.cmn.filter.AdminPortalFilter;
import com.ad.cmn.filter.ClmFilter;
import com.ad.cmn.filter.TossFilter;

@Configuration
public class RouterConfig {
	
	@Bean
	public RouteLocator adminPortalRouter(RouteLocatorBuilder builder) {
		System.out.println(builder.toString());
		return builder.routes()
			.route("path_route", r -> r.path("/adgw/01/**")
					.uri("http://localhost:17080/"))
			.build();
	}
	
	@Bean
	public RouteLocator tossRouter(RouteLocatorBuilder builder) {
		System.out.println(builder.toString());
		return builder.routes()
			.route("path_route", r -> r.path("/adgw/02/**")
					.uri("http://localhost:18080/"))
			.build();
	}
	
	@Bean
	public RouteLocator clmRouter(RouteLocatorBuilder builder) {
		System.out.println(builder.toString());
		
		return builder.routes()
			.route("path_route", r -> r.path("/adgw/03/**")
					.uri("http://localhost:19080/")
					//.filter(new ClmFilter())
					)
			.build();
	}
}
